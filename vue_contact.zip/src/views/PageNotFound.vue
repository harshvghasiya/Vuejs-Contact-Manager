<template>
<h2 class="text-center text-danger mt-5">404 ! Page Not Found</h2>
</template>

<script>
// import { def } from "@vue/shared";

export default{
    name:'PageNotFound',
}
</script>